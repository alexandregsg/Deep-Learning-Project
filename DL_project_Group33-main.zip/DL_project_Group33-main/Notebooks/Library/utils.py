from keras.callbacks import ModelCheckpoint, CSVLogger, LearningRateScheduler, EarlyStopping
from pathlib import Path
from datetime import datetime

import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import matplotlib
import seaborn as sns
import os
from PIL import Image, ImageFilter

from sklearn.model_selection import train_test_split
import shutil

import random


from sklearn.model_selection import StratifiedKFold

from tensorflow.keras import Model
from tensorflow.keras.layers import Rescaling, Dense, Resizing, CenterCrop
from tensorflow.keras.applications import MobileNetV2


import tensorflow as tf
from keras.layers import Input, Rescaling, Dense


from tensorflow.keras import Model, Input
from tensorflow.keras.layers import Flatten, Dense, Rescaling, Dropout
from tensorflow.keras.applications import VGG16
from keras.layers import Rescaling, RandAugment



# 1. EDA

## Check for corrupted images
## source: https://drlee.io/identifying-corrupted-images-before-feeding-them-into-a-cnn-13397844ef3c
def is_image_valid(path):
    try:
        Image.open(path).verify()
        return True
    except:
        return False


## check for empty images - images with size (0, 0)
def is_image_empty(path):
    try:
        img = Image.open(path)
        return img.size == (0, 0)
    except:
        return True
    

## Get image format
def get_image_format(path):
    try:
        img = Image.open(path)
        return img.format # Return the format of the image
    except:
        return None



## Check for unusual aspect ratios
def is_aspect_ratio_unusual(path):
    try:
        img = Image.open(path)
        width, height = img.size
        aspect_ratio = width / height
        return aspect_ratio < 0.1 or aspect_ratio > 10 # aspect_ratio > 10: very wide and short, aspect_ratio < 0.1: very tall and narrow
    except:
        return True



## Function to check image mode (e.g., 'RGB', 'L', etc.)
def check_mode(img_path):
    try:
        with Image.open(img_path) as img:
            return img.mode
    except:
        return None




## Function to display images 
## source https://stackoverflow.com/questions/41793931/plotting-images-side-by-side-using-matplotlib
## source https://keestalkstech.com/plotting-a-grid-of-pil-images-in-jupyter/

def display_images(image_paths, titles=None):
    """Display images in a grid."""
    n = len(image_paths)
    cols = 3
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(15, 5 * rows))
    axes = axes.flatten()
    
    for i, img_path in enumerate(image_paths):
        img = Image.open(img_path)
        axes[i].imshow(img)
        axes[i].axis('off')
        if titles:
            axes[i].set_title(titles[i])
    
    for j in range(i + 1, len(axes)):
        axes[j].axis('off')
    
    plt.tight_layout()
    plt.show()



# 2. Preprocessing


# 2.1 Approach 1: Outlier removal 

## Display the top n images with the most likely label errors
def display_ranked_label_errors(X, y_int, pred_probs, class_names, ranked_indices, n=5):
    #Display the top n images with the highest label error likelihood as determined by Cleanlab.

    #Parameters:
      #X               : numpy array of images, shape (n_samples, height, width, channels)
     # y_int           : numpy array of true labels as integers (1D array, length n_samples)
      #pred_probs      : numpy array of predicted probability distributions, shape (n_samples, num_classes)
      #class_names     : list of class names corresponding to the integer labels
      #ranked_indices  : array/list of indices sorted in descending order of label error likelihood
      #n               : number of images to display (default is 5)
    
    # Select the top n indices based on label error ranking
    top_indices = ranked_indices[:n]
    
    # Compute grid layout: at most 3 columns
    cols = min(n, 3)
    rows = (n + cols - 1) // cols

    fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 5 * rows))
    
    # Ensure axes is a 1D array for easy iteration
    if rows * cols > 1:
        axes = axes.flatten()
    else:
        axes = [axes]

    # Loop through top indices and display each image
    for i, idx in enumerate(top_indices):
        # X[idx] is the image array; convert to uint8 for proper display if needed.
        axes[i].imshow(X[idx].astype('uint8'))
        axes[i].axis('off')
        # Determine predicted and true classes
        pred_label = class_names[np.argmax(pred_probs[idx])]
        true_label = class_names[y_int[idx]]
        axes[i].set_title(f"Pred: {pred_label}\nTrue: {true_label}\nIdx: {idx}")
    
    # Hide any unused axes (if grid has more cells than images)
    for j in range(i + 1, rows * cols):
        axes[j].axis('off')
    
    plt.tight_layout()
    plt.show()


## Display top 10 label error images for each class
def display_label_errors_for_class_range(
    X, 
    y_int, 
    pred_probs, 
    class_names, 
    ranked_indices, 
    start, 
    end, 
    n=10
):
    """
    Display the top n label error images for each class in a specified range,
    including the self-confidence (predicted probability) for the given label.
    
    Parameters:
      X              : numpy array of images, shape (n_samples, height, width, channels).
      y_int          : 1D numpy array of true labels as integers (length = n_samples).
      pred_probs     : numpy array of predicted probability distributions, shape (n_samples, num_classes).
      class_names    : list of class names corresponding to the label indices.
      ranked_indices : array or list of indices sorted by label error likelihood (most suspicious first).
      start          : starting index (inclusive) in class_names (e.g., 0).
      end            : ending index (exclusive) in class_names (e.g., 3).
      n              : number of images to display for each class (default is 10).
    """
    for class_idx in range(start, end):
        target_class = class_names[class_idx]
        print(f"\nDisplaying top {n} label error images for class '{target_class}' (Index {class_idx})")
        
        # Filter the ranked indices to only include samples with true label equal to target_class.
        filtered_indices = [idx for idx in ranked_indices if y_int[idx] == class_idx]
        
        if not filtered_indices:
            print(f"No label issues detected for class '{target_class}'.")
            continue
        
        # Select the top n indices from this filtered list.
        top_indices = filtered_indices[:n]
        
        # Set up a grid with at most 3 columns.
        cols = min(n, 3)
        rows = (n + cols - 1) // cols
        fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 5 * rows))
        
        # Flatten the axes for easier iteration.
        if rows * cols > 1:
            axes = axes.flatten()
        else:
            axes = [axes]
            
        # Display each image with its details.
        for i, idx in enumerate(top_indices):
            axes[i].imshow(X[idx].astype('uint8'))
            axes[i].axis('off')
            pred_label = class_names[np.argmax(pred_probs[idx])]
            true_label = class_names[y_int[idx]]
            # Self-confidence for the true label.
            confidence = pred_probs[idx][y_int[idx]]
            axes[i].set_title(f"Pred: {pred_label}\nTrue: {true_label}\nConf: {confidence:.5f}\nIdx: {idx}")
        
        # Turn off any extra axes.
        for j in range(i + 1, rows * cols):
            axes[j].axis('off')
        
        plt.tight_layout()
        plt.show()


# 2.2 Approach 2: Manual outlier removal

# source: https://github.com/JiahaoFang77/AIDB-unstructured_database/blob/7419e9088c02303abb448ae60ceb53e3ab03af46/AIDB_project_2/mlmapping2.py
def get_all_relative_image_paths(path):
    """
    Go one level deep (phylum_family folders) and collect relative paths to all image files.
    """
    relative_paths = []

    for phylum_family_folder in os.listdir(path):
        folder_path = os.path.join(path, phylum_family_folder)
        
        if os.path.isdir(folder_path):
            for file in os.listdir(folder_path):
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
                    rel_path = os.path.join(phylum_family_folder, file)
                    relative_paths.append(rel_path.replace("\\", "/"))  # Normalize path for consistency

    return relative_paths





# 2.3 Class imabalnce strategy

# Def function to apply each of the transformations suggested by the paper Strategies for Tackling the Class Imbalance Problem in Marine Image Classification
# Apply 90-degree rotation, Gaussian Blur, Flipping horizontally, Flipping vertically
# Source: https://www.sciencedirect.com/science/article/pii/S235197892200001X

def apply_transformations(image_path):
    """
    Apply a series of transformations to an image.
    
    Parameters:
      image_path : str : Path to the image file.
    
    Returns:
      transformed_images : list : List of transformed images.
    """
    img = Image.open(image_path)
    transformed_images = []

    # 90-degree rotation
    rotated_img = img.rotate(90)
    transformed_images.append(rotated_img)

    # Gaussian Blur
    blurred_img = img.filter(ImageFilter.GaussianBlur(radius=1)) # radius corresponds to the sigma
    transformed_images.append(blurred_img)

    # Flipping horizontally
    flipped_horizontally = img.transpose(method=Image.FLIP_LEFT_RIGHT)
    transformed_images.append(flipped_horizontally)

    # Flipping vertically
    flipped_vertically = img.transpose(method=Image.FLIP_TOP_BOTTOM)
    transformed_images.append(flipped_vertically)

    return transformed_images



# source: https://scispace.com/pdf/strategies-for-tackling-the-class-imbalance-problem-in-3shh1w6onl.pdf
def oversample_adaptive_r5075100(input_dir, max_image_count, output_dir):
    """
    Apply r₅₀,₇₅,₁₀₀ strategy to augment underrepresented families with a 3× cap.
    
    Folder format: data/phylum_family/
    """
    os.makedirs(output_dir, exist_ok=True)
    augmented_metadata = []

    for folder_name in sorted(os.listdir(input_dir)):
        folder_path = os.path.join(input_dir, folder_name)
        if not os.path.isdir(folder_path):
            continue

        # Parse phylum and family
        if "_" not in folder_name:
            print(f"Skipping improperly named folder: {folder_name}")
            continue

        phylum, family = folder_name.split("_", 1)

        image_files = [
            f for f in os.listdir(folder_path)
            if f.lower().endswith(('.jpg', '.jpeg', '.png'))
        ]

        current_count = len(image_files)
        max_cap = current_count * 3  # Cap = 3× original size

        # r₅₀,₇₅,₁₀₀ logic
        if current_count <= max_image_count * 0.25:
            target_count = int(max_image_count * 0.5)
        elif current_count <= max_image_count * 0.5:
            target_count = int(max_image_count * 0.75)
        else:
            target_count = max_image_count

        target_count = min(target_count, max_cap)

        # ✅ Step 1: Copy original images to output_dir
        output_folder = os.path.join(output_dir, folder_name)
        os.makedirs(output_folder, exist_ok=True)

        for img_file in image_files:
            src = os.path.join(folder_path, img_file)
            dst = os.path.join(output_folder, img_file)
            shutil.copy2(src, dst)

            augmented_metadata.append({
                'phylum': phylum,
                'family': family,
                'full_path': dst
            })

        # ✅ Step 2: Augment if needed
        if current_count >= target_count:
            continue

        for img_file in image_files:
            if current_count >= target_count:
                break

            src_path = os.path.join(folder_path, img_file)
            try:
                transformed_images = apply_transformations(src_path)
            except Exception as e:
                print(f"Failed on {src_path}: {e}")
                continue

            for i, img in enumerate(transformed_images):
                if current_count >= target_count:
                    break

                new_filename = f"{os.path.splitext(img_file)[0]}_aug_{i}.jpg"
                save_path = os.path.join(output_folder, new_filename)
                img.save(save_path)

                current_count += 1

                augmented_metadata.append({
                    'phylum': phylum,
                    'family': family,
                    'full_path': save_path
                })

    # Save final metadata
    metadata_df = pd.DataFrame(augmented_metadata)
    metadata_df.to_csv(os.path.join(output_dir, "oversampled_metadata.csv"), index=False)




# 3. Modeling 

## Function used in Lab 5
def exp_decay_lr_scheduler(
    epoch: int,
    current_lr: float,
    factor: float = 0.95
) -> float:
    """
    Exponential decay learning rate scheduler
    """

    current_lr *= factor

    return current_lr   



def get_callbacks(
    base_dir="training_logs",
    model_name ="confident_model"
):
    """
    Returns a list of Keras callbacks including:
    - ModelCheckpoint
    - CSVLogger
    - LearningRateScheduler
    - EarlyStopping
    """


    # Get current timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")

    # Generate filenames with timestamp
    checkpoint_name = f"DL_{model_name}_checkpoint_{timestamp}.keras"
    metrics_filename = f"DL_{model_name}_metrics_{timestamp}.csv"
    
    base_dir = Path(base_dir)
    base_dir.mkdir(parents=True, exist_ok=True)  # Create directory if it doesn't exist

    checkpoint_path = base_dir / checkpoint_name
    metrics_path = base_dir / metrics_filename

    checkpoint_callback = ModelCheckpoint(
        checkpoint_path,
        monitor="val_loss",
        save_best_only=True,
        verbose=1
    )

    metrics_callback = CSVLogger(metrics_path)

    lr_scheduler_callback = LearningRateScheduler(exp_decay_lr_scheduler)

    early_stopping_callback = EarlyStopping(
        monitor="val_loss",
        patience=3,  # Adjust as needed
        restore_best_weights=True,
        verbose=1
    )

    return [checkpoint_callback, metrics_callback, lr_scheduler_callback, early_stopping_callback]



# CleanLab use case
"""
clf = KerasWrapperModel(
    model=build_model,
    model_kwargs={'input_shape': (224, 224, 3), 'num_classes': num_classes},
    compile_kwargs={
        'optimizer': 'adam',
        'loss': 'categorical_crossentropy',
        'metrics': ['accuracy']
    }
)

callbacks = get_callbacks()

clf.fit(X_train, y_train, 
        epochs=10, 
        batch_size=32, 
        validation_data=(X_val, y_val),
        callbacks=callbacks) # Here

"""
# Pre-tained keras model use case

"""
def build_model(input_shape=(224, 224, 3), num_classes=202):
    inputs = Input(shape=input_shape)
    x = Rescaling(1. / 255)(inputs)
    x = MobileNetV2(include_top=False, pooling='avg', weights='imagenet')(x)
    outputs = Dense(num_classes, activation='softmax')(x)
    return Model(inputs, outputs)


num_classes = 202
model = build_model(num_classes=num_classes)
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

callbacks = get_callbacks(
    checkpoint_name="mobilenet_checkpoint.keras",
    metrics_filename="mobilenet_metrics.csv",
    base_dir="mobilenet_logs"
)

model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=20,
    batch_size=32,
    callbacks=callbacks, #Here
    verbose=1
)



"""


## Augmented VGG16 

# Define the model
def build_augmented_vgg16(input_shape=(224, 224, 3), num_classes=10, value_range=(0.0, 1.0), dropout_rate=0.3):
    inputs = Input(shape=input_shape)

    # Preprocessing layers
    x = Rescaling(1. / 255)(inputs)
    # x = Resizing(224, 224, crop_to_aspect_ratio=True)(inputs) # First crops just enough from the longer side to get a square, then resizes


    # Augmentation layers
    x = RandAugment(value_range=value_range)(x)

    # Backbone
    base_model = VGG16(include_top=False, weights="imagenet", input_shape=input_shape)
    x = base_model(x)

    # Classifier
    x = Flatten()(x)
    x = Dropout(dropout_rate)(x)
    outputs = Dense(num_classes, activation="softmax")(x)

    return Model(inputs, outputs)

