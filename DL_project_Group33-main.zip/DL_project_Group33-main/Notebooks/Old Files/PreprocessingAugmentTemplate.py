from Library.BaseLineModel import BaselineModel
from typing import Self
from keras import Model
from keras.layers import Rescaling, RandAugment, Dense, GlobalAveragePooling2D, Dropout

class Preprocessing_Augment_Template(Model):
    def __init__(self: Self, base_model=BaselineModel, augment=False, num_classes=202, resolution=224):
        super().__init__()

        self.n_classes = num_classes
        self.rescale_layer = Rescaling(scale=1 / 255.0)

        # augment only if wanted
        self.augment = augment
        if self.augment:
            self.augmentation_layer = RandAugment(value_range=(0.0, 1.0))
        else:
            self.augmentation_layer = None

        self.model = base_model
        if self.model:
            self.pre_trained_architecture = base_model
        else:
            self.pre_trained_architecture = BaselineModel(input_shape=(resolution, resolution, 3), num_classes=num_classes)

        self.pooling = GlobalAveragePooling2D()
        self.dense1 = Dense(256, activation='relu')
        self.dropout1 = Dropout(0.25)
        self.dense2 = Dense(256, activation='relu')
        self.dropout2 = Dropout(0.25)
        self.output_layer = Dense(self.n_classes, activation='softmax')

    def build(self, input_shape):
        self.model.build(input_shape)

        self.rescale_layer.build(input_shape)
        shape = self.rescale_layer.compute_output_shape(input_shape)

        if self.augment:
            self.augmentation_layer.build(shape)
            shape = self.augmentation_layer.compute_output_shape(shape)

        self.model.build(shape)
        shape = self.model.compute_output_shape(shape)

        self.pooling.build(shape)
        shape = self.pooling.compute_output_shape(shape)

        self.dense1.build(shape)
        shape = self.dense1.compute_output_shape(shape)

        self.dropout1.build(shape)
        shape = self.dropout1.compute_output_shape(shape)

        self.dense2.build(shape)
        shape = self.dense2.compute_output_shape(shape)

        self.dropout2.build(shape)
        shape = self.dropout2.compute_output_shape(shape)

        self.output_layer.build(shape)
        shape = self.output_layer.compute_output_shape(shape)

        super().build(input_shape)

    # Forward Call
    def call(self, inputs):
        x = self.rescale_layer(inputs)
        
        if self.augment:
            x = self.augmentation_layer(x)

        x = self.model(x, training=True)  # base_model always in inference mode unless fine-tuning

        x = self.pooling(x)
        x = self.dense1(x)
        x = self.dropout1(x, training=True)
        x = self.dense2(x)
        x = self.dropout2(x, training=True)
        x = self.output_layer(x)
        return x