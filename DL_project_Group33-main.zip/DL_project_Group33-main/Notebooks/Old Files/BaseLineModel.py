from keras import Model
from keras.layers import Rescaling, Resizing, RandAugment, CenterCrop
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, GlobalAveragePooling2D, Dropout

class BaselineModel(Model):
    def __init__(self, input_shape=(224, 224, 3), num_classes=202):
        super(BaselineModel, self).__init__()
        self.resize = Resizing(224, 224)
        self.crop = CenterCrop(224, 224)
        self.rescale = Rescaling(1./255)

        self.conv1 = Conv2D(32, (3, 3), activation='relu', padding='same')
        self.pool1 = MaxPooling2D((2, 2))

        self.conv2 = Conv2D(64, (3, 3), activation='relu', padding='same')
        self.pool2 = MaxPooling2D((2, 2))

        self.conv3 = Conv2D(128, (3, 3), activation='relu', padding='same')
        self.pool3 = MaxPooling2D((2, 2))

        self.conv4 = Conv2D(256, (3, 3), activation='relu', padding='same')
        self.pool4 = MaxPooling2D((2, 2))

        self.global_pool = GlobalAveragePooling2D()
        self.flatten = Flatten()
        self.dense1 = Dense(256, activation='relu')
        self.dropout1 = Dropout(0.25)
        self.dense2 = Dense(256, activation='relu')
        self.dropout2 = Dropout(0.25)
        self.output_layer = Dense(num_classes, activation='softmax')

    def call(self, inputs):
        x = self.rescale(inputs)
        x = self.crop(x)
        x = self.resize(x)

        x = self.conv1(x)
        x = self.pool1(x)

        x = self.conv2(x)
        x = self.pool2(x)

        x = self.conv3(x)
        x = self.pool3(x)

        x = self.conv4(x)
        x = self.pool4(x)

        x = self.global_pool(x)
        x = self.flatten(x)
        x = self.dense1(x)
        x = self.dropout1(x)
        x = self.dense2(x)
        x = self.dropout2(x)
        return self.output_layer(x)